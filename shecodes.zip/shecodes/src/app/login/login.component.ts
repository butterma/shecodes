import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
import {Router} from '@angular/router';

import {UserService} from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   
  createForm:FormGroup;
  constructor(private userService:UserService,private fb:FormBuilder,private router:Router) { 
    this.createForm=this.fb.group({
      username:['',Validators.required],
      password:''
    });
  }

login(username,password){
  try{
 var res= this.userService.getUserByUsernameAndPassword(username,password);
 res.subscribe(
   data=> this.router.navigate(['/']),
  error=>console.log("User not approved yet")   
  );
}
  catch(error){
    console.log("User not approved yet");
  }
  console.log(res);
}    
ngOnInit() {
  }

}
