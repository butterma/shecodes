export interface User {
        _id:String;
        username:String;
        password:String;
        role:String;
        course:String;
        branch: String;
    }

