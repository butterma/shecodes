import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  uri='http://localhost:3000';
  constructor(private http:HttpClient) { }

  addUser(email,password,branch,course){
    const user={
      username:email,
      password:password,
      branch:branch,
      course:course,
      approved:false      
    };
    return this.http.post(`${this.uri}/users/signup`,user);
  }

  sendMail(email){
    return this.http.post(`${this.uri}/users/sendMail`,{email:email});
  }
  getUsers(){
    return this.http.get(`${this.uri}/users`);
  }

  getUserById(id){
    return this.http.get(`${this.uri}/users/${id}`);
  }

  getUserByUsernameAndPassword(usrnm,passwrd){
    console.log("in function get user");
    return this.http.post(`${this.uri}/users/login`,{username:usrnm,password:passwrd});
  }

  signupUser(usrnm,passwrd,brnch,crs){
    console.log("in function signup");
    return this.http.post(`${this.uri}/users/signup`,{username:usrnm,password:passwrd,branch:brnch,course:crs});
  }
  updateUser(id,email,password,role,course,branch){
    const user={
      username:email,
      password:password,
      role:role,
      course:course,
      branch:branch
    };
    return this.http.post(`${this.uri}/users/update/${id}`, user);
  }

  deleteUser(id){
    return this.http.get(`${this.uri}/users/delete/${id}`);
  }
}
