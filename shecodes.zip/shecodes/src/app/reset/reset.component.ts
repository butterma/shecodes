import { Component, OnInit } from '@angular/core';

import {FormGroup,FormBuilder,Validators} from '@angular/forms';
import {Router} from '@angular/router';

import {UserService} from '../services/user.service';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {

  createForm:FormGroup;

  constructor(private userService:UserService,private fb:FormBuilder,private router:Router) {
    this.createForm=this.fb.group({
      password:'',
      confirmPassword:''
    });
   }

  ngOnInit() {
  }

}
